#include <iostream>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <cstring>
#define PORT 35541

using namespace std;

int main()
{
    int client = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    connect(client, (struct sockaddr *)&serverAddr, sizeof(serverAddr));
    cout << "server connected successfully" << endl;
    char str1[100];
    cout << "enter: " << endl;
    cin >> str1;
    send(client, &str1, sizeof(str1), 0);
    close(client);
}