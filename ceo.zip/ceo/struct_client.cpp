#include<iostream>                                                                                                                          
#include<cstring>                                                                                                                           
#include<netinet/in.h>                                                                                                                      
#include<unistd.h>                                                                                                                          
#include<string>                                                                                                                            
#include<sys/socket.h>                                                                                                                      
#define PORT 53550                                                                                                                          
using namespace std;                                                                                                                        
struct num{                                                                                                                                 
        int a;                                                                                                                              
        int b;                                                                                                                              
        int c;                                                                                                                              
};                                                                                                                                          
int main(){                                                                                                                                 
        int client=socket(AF_INET,SOCK_STREAM,0);                                                                                           
        sockaddr_in serverAddr;                                                                                                             
        serverAddr.sin_family=AF_INET;                                                                                                      
        serverAddr.sin_port=htons(PORT);                                                                                                    
        serverAddr.sin_addr.s_addr=INADDR_ANY;                                                                                              
        connect(client,(struct sockaddr*)&serverAddr,sizeof(serverAddr));                                                                   
        cout<<"Server connected successfully";                                                                                              
        struct num q;                                                                                                                       
        cout<<"Enter the no. : "<<endl;                                                                                                     
        cin>>q.a;                                                                                                                           
        send(client,(struct num*)&q,sizeof(q),0);                                                                                           
        struct num p;                                                                                                                       
        recv(client,(struct num*)&p,sizeof(p),0);                                                                                           
        cout<<"Square of"<<p.a<<" is"<<p.b<<endl;                                                                                           
        cout<<"Cube of"<<p.a<<" is"<<p.c<<endl;                                                                                             
        close(client);                                                                                                                      
}