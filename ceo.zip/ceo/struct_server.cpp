#include<iostream>                                                                                                                          
#include<netinet/in.h>                                                                                                                      
#include<string>                                                                                                                            
#include<sys/socket.h>                                                                                                                      
#include<unistd.h>                                                                                                                          
#define PORT 53550                                                                                                                          
using namespace std;                                                                                                                        
struct num{                                                                                                                                 
        int a;                                                                                                                              
        int b;                                                                                                                              
        int c;                                                                                                                              
};                                                                                                                                          
int main(){                                                                                                                                 
        int server=socket(AF_INET,SOCK_STREAM,0);                                                                                           
        sockaddr_in serverAddr;                                                                                                             
        serverAddr.sin_family=AF_INET;                                                                                                      
        serverAddr.sin_port=htons(PORT);                                                                                                    
        serverAddr.sin_addr.s_addr=INADDR_ANY;                                                                                              
        bind(server,(struct sockaddr*)&serverAddr,sizeof(serverAddr));                                                                      
        listen(server,1);                                                                                                                   
        int clientsocket=accept(server,nullptr,nullptr);                                                                                    
        struct num q;                                                                                                                       
        recv(clientsocket,(struct num*)&q,sizeof(q),0);                                                                                     
        q.b=(q.a)*(q.a);                                                                                                                    
        q.c=(q.b)*(q.a);                                                                                                                    
        send(clientsocket,(struct num*)&q,sizeof(q),0);                                                                                     
        cout<<"Message sent"<<endl;                                                                                                         
        close(server);                                                                                                                      
}