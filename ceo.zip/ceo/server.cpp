#include<iostream>                                                                                                                                                      
#include<string.h>                                                                                                                                                      
#include<netinet/in.h>                                                                                                                                                  
#include<sys/socket.h>                                                                                                                                                  
#include<unistd.h>                                                                                                                                                      
#include<cstring>                                                                                                                                                       
                                                                                                                                                                        
#define PORT 35541                                                                                                                                                      
                                                                                                                                                                        
using namespace std;                                                                                                                                                    
                                                                                                                                                                        
int main(){                                                                                                                                                             
        int server=socket(AF_INET, SOCK_STREAM,0);                                                                                                                      
        sockaddr_in serverAddr;                                                                                                                                         
        serverAddr.sin_family=AF_INET;                                                                                                                                  
        serverAddr.sin_port=htons(PORT);                                                                                                                                
        serverAddr.sin_addr.s_addr=INADDR_ANY;                                                                                                                          
        bind(server,(struct sockaddr*)&serverAddr, sizeof(serverAddr));                                                                                                 
        listen(server,1);                                                                                                                                               
        cout<<"Server listening.."<<endl;                                                                                                                               
        int clientsocket=accept(server,nullptr,nullptr);                                                                                                                
        cout<<"Connected"<<endl;                                                                                                                                        
        char str1[100];                                                                                                                                                 
        recv(clientsocket,str1,sizeof(str1),0);                                                                                                                         
        cout<<"from : "<<str1<<"\n"<<"response: ";                                                                                                                      
        //cout<<"msg sent"<<endl;                                                                                                                                       

        close(server);                                                                                                                                                  
}                               